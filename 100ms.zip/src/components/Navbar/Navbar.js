import React from 'react';
import "./Navbar.css";

function Navbar() {

    return (
        <div className="navbar">
            <img src="https://www.100ms.live/assets/logo.svg" alt="img" />
        </div>
    );
}
export default Navbar;